const nodemailer = require("nodemailer");

const transport = nodemailer.createTransport({
  host: "mail.expertbeton.net",
  port: 465,
  secure: true,
  auth: {
    user: "info@expertbeton.net",
    pass: "*/Passw0rd2023",
  },
});

/**
 * ####################
 * ## Generate Error ##
 * ####################
 */

const generateError = (msg, status) => {
  const err = new Error(msg);
  err.httpStatus = status;
  throw err;
}

/**
 * ###############
 * ## Send Mail ##
 * ###############
 */

const sendMail = async (subject, text) => {
  try {
    await transport.sendMail({
      from: 'info@expertbeton.net',
      to: 'godinho@expertbeton.net',
      subject,
      text,
    });
  } catch (err) {
    generateError('Error enviar o email');
  }
};

module.exports = { generateError, sendMail };