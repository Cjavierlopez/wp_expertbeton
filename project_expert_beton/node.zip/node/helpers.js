const nodemailer = require("nodemailer");

const { SMTP_USER, SMTP_RECEIVER} = process.env;

const transport = nodemailer.createTransport({
  host: "mail.expertbeton.net",
  port: 465,
  secure: true,
  auth: {
    user: "info@expertbeton.net",
    pass: "*/Passw0rd2023",
  },
});

/**
 * ####################
 * ## Generate Error ##
 * ####################
 */

const generateError = (msg, status) => {
  const err = new Error(msg);
  err.httpStatus = status;
  throw err;
}

/**
 * ###############
 * ## Send Mail ##
 * ###############
 */

const sendMail = async (subject, text) => {
  try {
    await transport.sendMail({
      from: SMTP_USER,
      to: SMTP_RECEIVER,
      subject,
      text,
    });
    console.log('ENVIADO');
  } catch (err) {
    console.error(err);
    generateError('Error enviar o email');
  }
};

module.exports = { generateError, sendMail };